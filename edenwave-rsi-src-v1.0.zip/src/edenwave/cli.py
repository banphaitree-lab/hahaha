
import argparse, json
from pathlib import Path
from .bundle import build_channels, build_bundle, bundle_root_from_channels

def write_json(path: Path, obj: dict):
    path.write_text(json.dumps(obj, sort_keys=True, separators=(",", ":")) + "\n")

def cmd_build(args):
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    ch = build_channels()
    for name, obj in ch.items():
        write_json(out / f"{name}.json", obj)
    bundle = build_bundle(ch)
    write_json(out / "bundle_v1_5.json", bundle)
    print("Bundle root:", bundle["bundle_root_sha256"])

def cmd_verify(args):
    p = Path(args.path)
    files = {
        "B_channel": p / "B_channel.json",
        "rotor_channel": p / "rotor_channel.json",
        "HB_equilibrium": p / "HB_equilibrium.json",
        "payout_derived_v1_1": p / "payout_derived_v1_1.json",
    }
    ch = {k: json.loads(files[k].read_text()) for k in files}
    root = bundle_root_from_channels(ch)
    print("Recomputed bundle root:", root)
    if args.root:
        print("Matches expected:", root == args.root)

def cmd_opreturn(args):
    root = args.root
    print("OP_RETURN hex:", "52534931" + root)

def main():
    ap = argparse.ArgumentParser(prog="edenwave")
    sub = ap.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("build", help="Emit channels + bundle into an output folder")
    b.add_argument("--out", default="out")
    b.set_defaults(func=cmd_build)

    v = sub.add_parser("verify", help="Verify a folder containing channel JSONs")
    v.add_argument("--path", default="out")
    v.add_argument("--root", help="Expected bundle root (hex)")
    v.set_defaults(func=cmd_verify)

    o = sub.add_parser("opreturn", help="Print OP_RETURN payload for a bundle root")
    o.add_argument("--root", required=True)
    o.set_defaults(func=cmd_opreturn)

    args = ap.parse_args()
    args.func(args)
