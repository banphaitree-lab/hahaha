
import cmath, math
from typing import Tuple

def _series_center1_logx(x: complex, N: int) -> complex:
    z = x - 1
    s = 0+0j
    powz = z
    sign = 1.0
    for k in range(1, N+1):
        s += (sign * powz) / k
        powz *= z
        sign *= -1.0
    return s

def _laurent_from_xminus1(x: complex, N: int) -> complex:
    z = x - 1
    s = 0+0j
    invz = 1/z
    powinv = invz
    sign = -1.0
    for k in range(1, N+1):
        s += (sign * powinv) / k
        powinv *= invz
        sign *= -1.0
    return cmath.log(z) - s

def _local_around_xi(x: complex, xi: complex, N: int) -> complex:
    z = x - xi
    m = math.floor(cmath.phase(z) / (2*math.pi))
    s = 0+0j
    pow_u = z
    inv_xi = 1/xi
    sign = 1.0
    for k in range(1, N+1):
        s += (sign * pow_u / k) * (inv_xi**k)
        pow_u *= z
        sign *= -1.0
    return (2j*math.pi*m) + cmath.log(xi) + s

def B(x: complex, xi: complex = 1+1j, N: int = 40) -> complex:
    z = x - 1
    if abs(z) < 1:
        a = _series_center1_logx(x, N)
        # safe fallback for b near boundary
        b = _laurent_from_xminus1(x if abs(z)>1e-12 else (1+1e-9+0j), N)
    else:
        a = _series_center1_logx(1 + (z/abs(z))*0.5, N)
        b = _laurent_from_xminus1(x, N)
    if abs(x - xi) < abs(xi):
        c = _local_around_xi(x, xi, N)
    else:
        direction = (x - xi) / abs(x - xi)
        x_proj = xi + direction * (abs(xi) * 0.999)
        c = _local_around_xi(x_proj, xi, N)
    return a + b + c
