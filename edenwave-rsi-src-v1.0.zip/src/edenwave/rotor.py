
import math
from .triad import B

C0 = 0.0955296575

def rotor_R(x: complex, xi: complex = 1+1j, N: int = 40) -> float:
    Bz = B(x, xi, N)
    re_power = (Bz ** 39).real
    inner = 12.12 * math.cos(C0 * re_power)
    return math.tan(inner) / 40.0
